"""
Synthetic Cattle Sensor Data Generator
======================================
Simulates smart ear-tag telemetry for a herd over time:
  - body_temp_c     : body temperature (deg C)
  - activity_index  : 0-100 movement/activity score from accelerometer
  - rumination_min  : minutes spent ruminating per hour (key early illness signal)
  - heart_rate_bpm  : resting heart rate
  - gps_lat/lon     : position (small paddock-scale drift)
  - ambient_temp_c  : weather at the animal's location

Illness model:
  For each animal, we randomly decide if/when it develops an illness event.
  In the 24-72h BEFORE the illness is "visible" (labelled sick), we inject a
  gradual physiological drift: rising temp, falling rumination, falling
  activity, rising heart rate, reduced movement radius (isolation behavior).
  This mimics real pre-clinical illness signatures in dairy/beef cattle
  research (reduced rumination + reduced activity are the two most
  well-documented early indicators).

Output: data/herd_sensor_data.csv
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

RNG = np.random.default_rng(42)

N_COWS = 60
DAYS = 21
HOURS = DAYS * 24
START = datetime(2026, 6, 1)

PADDOCK_CENTER = (46.8772, -96.7898)  # Fargo, ND area as a stand-in ranch location


def cow_baseline():
    """Each cow has its own healthy baseline (individual variation matters a lot in real herds)."""
    return {
        "temp_base": RNG.normal(38.6, 0.25),       # deg C, healthy cattle ~38.0-39.3
        "activity_base": RNG.normal(55, 8),
        "rumination_base": RNG.normal(480, 40),    # minutes/day typical range 400-550
        "hr_base": RNG.normal(65, 6),
        "home_lat": PADDOCK_CENTER[0] + RNG.normal(0, 0.004),
        "home_lon": PADDOCK_CENTER[1] + RNG.normal(0, 0.004),
    }


def weather_series(hours):
    """Simple seasonal + daily temperature cycle with noise, deg C."""
    t = np.arange(hours)
    seasonal = 22 + 6 * np.sin(2 * np.pi * (t / (24 * 365)))
    daily = 6 * np.sin(2 * np.pi * (t / 24) - np.pi / 2)
    noise = RNG.normal(0, 1.2, size=hours)
    return seasonal + daily + noise


def generate_cow_series(cow_id, base, weather):
    hours = HOURS
    t = np.arange(hours)

    # --- decide illness event for this cow ---
    will_get_sick = RNG.random() < 0.35  # 35% of herd experiences a health event in window
    onset_hour = None
    if will_get_sick:
        onset_hour = int(RNG.integers(72, hours - 24))  # avoid edges

    temp = np.full(hours, base["temp_base"], dtype=float)
    activity = np.full(hours, base["activity_base"], dtype=float)
    rumination = np.full(hours, base["rumination_base"] / 24.0, dtype=float)  # per-hour
    hr = np.full(hours, base["hr_base"], dtype=float)
    lat = np.full(hours, base["home_lat"], dtype=float)
    lon = np.full(hours, base["home_lon"], dtype=float)

    # daily circadian rhythm (cattle are more active in daytime, ruminate more at night)
    hour_of_day = t % 24
    activity += 10 * np.sin(2 * np.pi * (hour_of_day - 6) / 24)
    rumination += 4 * np.cos(2 * np.pi * (hour_of_day - 2) / 24)

    # weather influence (heat stress raises temp/HR slightly, drops activity)
    heat_stress = np.clip((weather - 28) / 10, 0, None)
    temp += heat_stress * 0.15
    activity -= heat_stress * 6
    hr += heat_stress * 4

    # baseline sensor + biological noise
    temp += RNG.normal(0, 0.08, hours)
    activity += RNG.normal(0, 4, hours)
    rumination += RNG.normal(0, 2.5, hours)
    hr += RNG.normal(0, 2.5, hours)
    lat += RNG.normal(0, 0.0006, hours)
    lon += RNG.normal(0, 0.0006, hours)

    label_sick = np.zeros(hours, dtype=int)          # ground-truth: clinically sick now
    label_will_be_sick_48h = np.zeros(hours, dtype=int)  # PREDICTION TARGET

    if will_get_sick:
        illness_len = int(RNG.integers(48, 120))  # illness lasts 2-5 days once visible
        pre_onset_ramp = 60  # hours of prodromal (pre-clinical) drift before visible symptoms

        ramp_start = max(0, onset_hour - pre_onset_ramp)
        for h in range(ramp_start, min(onset_hour + illness_len, hours)):
            if h < onset_hour:
                # prodromal phase: gradual drift, worsening as we approach onset
                progress = (h - ramp_start) / max(1, (onset_hour - ramp_start))
                severity = progress ** 1.5
            else:
                # clinical phase: full severity, slowly recovering
                since_onset = h - onset_hour
                severity = max(0.15, 1.0 - since_onset / illness_len)
                label_sick[h] = 1

            temp[h] += severity * RNG.normal(1.1, 0.15)
            activity[h] -= severity * RNG.normal(22, 4)
            rumination[h] -= severity * RNG.normal(9, 2)
            hr[h] += severity * RNG.normal(18, 3)
            # isolation behavior: sick cattle drift from herd center / move less
            lat[h] += severity * RNG.normal(0, 0.002)
            lon[h] += severity * RNG.normal(0, 0.002)

        # label the 48h window BEFORE onset as positive class for early prediction
        target_start = max(0, onset_hour - 48)
        label_will_be_sick_48h[target_start:onset_hour] = 1

    rumination = np.clip(rumination, 0, None)
    activity = np.clip(activity, 0, 100)
    hr = np.clip(hr, 35, 140)

    df = pd.DataFrame({
        "cow_id": cow_id,
        "timestamp": [START + timedelta(hours=int(h)) for h in t],
        "hour_index": t,
        "body_temp_c": temp,
        "activity_index": activity,
        "rumination_min_per_hr": rumination,
        "heart_rate_bpm": hr,
        "gps_lat": lat,
        "gps_lon": lon,
        "ambient_temp_c": weather,
        "label_sick_now": label_sick,
        "label_sick_within_48h": label_will_be_sick_48h,
    })
    return df


def main():
    weather = weather_series(HOURS)
    all_dfs = []
    for i in range(N_COWS):
        cow_id = f"COW-{300 + i}"
        base = cow_baseline()
        df = generate_cow_series(cow_id, base, weather)
        all_dfs.append(df)

    full = pd.concat(all_dfs, ignore_index=True)
    out_path = os.path.join(SCRIPT_DIR, "herd_sensor_data.csv")
    full.to_csv(out_path, index=False)
    print(f"Generated {len(full):,} rows for {N_COWS} cows over {DAYS} days")
    print(f"Sick-window positive rate: {full['label_sick_within_48h'].mean():.3%}")
    print(f"Saved to {out_path}")


if __name__ == "__main__":
    main()
