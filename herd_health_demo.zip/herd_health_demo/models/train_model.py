"""
Train the 48h-ahead illness risk model.

Approach:
  - Gradient boosted trees (XGBoost) on engineered per-animal features.
  - Chosen over an LSTM/deep model for a v1 because: (a) tabular sensor
    features with strong domain engineering typically beat raw deep
    learning at this data volume, (b) it's fast to train/retrain per-herd,
    (c) SHAP gives exact, fast, per-prediction explanations -- critical for
    rancher trust ("why is my cow flagged?").
  - Time-based split (not random) since this is a forecasting problem:
    train on cows' earlier weeks, validate on later weeks, to avoid leakage.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import (
    roc_auc_score, average_precision_score, precision_recall_curve,
    classification_report, confusion_matrix
)

from features import build_features, FEATURE_COLUMNS

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(SCRIPT_DIR)
DATA_PATH = os.path.join(BASE_DIR, "data", "herd_sensor_data.csv")
MODEL_PATH = os.path.join(SCRIPT_DIR, "risk_model.joblib")
METRICS_PATH = os.path.join(SCRIPT_DIR, "metrics.json")


def time_based_split(feat: pd.DataFrame, split_hour: int):
    train = feat[feat["hour_index"] < split_hour]
    test = feat[feat["hour_index"] >= split_hour]
    return train, test


def main():
    raw = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
    feat = build_features(raw)

    max_hour = feat["hour_index"].max()
    split_hour = int(max_hour * 0.75)  # first 75% of the timeline to train, last 25% to test
    train, test = time_based_split(feat, split_hour)

    X_train, y_train = train[FEATURE_COLUMNS], train["label_sick_within_48h"]
    X_test, y_test = test[FEATURE_COLUMNS], test["label_sick_within_48h"]

    pos_rate = y_train.mean()
    scale_pos_weight = (1 - pos_rate) / max(pos_rate, 1e-6)

    model = xgb.XGBClassifier(
        n_estimators=250,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        eval_metric="aucpr",
        random_state=42,
    )
    model.fit(X_train, y_train)

    proba = model.predict_proba(X_test)[:, 1]
    preds = (proba >= 0.5).astype(int)

    auc = roc_auc_score(y_test, proba)
    ap = average_precision_score(y_test, proba)
    report = classification_report(y_test, preds, output_dict=True, zero_division=0)
    cm = confusion_matrix(y_test, preds).tolist()

    print(f"Train rows: {len(train):,} | Test rows: {len(test):,}")
    print(f"Test positive rate: {y_test.mean():.3%}")
    print(f"ROC-AUC: {auc:.3f}")
    print(f"Average Precision (PR-AUC): {ap:.3f}")
    print("Confusion matrix [[TN,FP],[FN,TP]]:", cm)
    print(classification_report(y_test, preds, zero_division=0))

    joblib.dump({"model": model, "feature_columns": FEATURE_COLUMNS}, MODEL_PATH)

    metrics = {
        "roc_auc": auc,
        "average_precision": ap,
        "confusion_matrix": cm,
        "classification_report": report,
        "train_rows": int(len(train)),
        "test_rows": int(len(test)),
        "test_positive_rate": float(y_test.mean()),
    }
    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"\nSaved model -> {MODEL_PATH}")
    print(f"Saved metrics -> {METRICS_PATH}")


if __name__ == "__main__":
    main()
