"""
Feature engineering for herd health prediction.

Key idea: absolute sensor values matter less than DEVIATION FROM EACH
ANIMAL'S OWN BASELINE and RECENT TREND. A cow that's always at 39.0C is
normal for her; a cow that jumps from 38.3C to 39.0C in 12 hours is not.
"""

import numpy as np
import pandas as pd

SENSOR_COLS = ["body_temp_c", "activity_index", "rumination_min_per_hr", "heart_rate_bpm"]


def build_features(df: pd.DataFrame, baseline_hours: int = 168) -> pd.DataFrame:
    """
    baseline_hours: rolling window (e.g. 168h = 7 days) used as each cow's
    personal "healthy" reference point, computed on a trailing window that
    excludes the most recent 12h (so the baseline isn't itself contaminated
    by the onset of illness).
    """
    df = df.sort_values(["cow_id", "hour_index"]).reset_index(drop=True)
    out = [df[["cow_id", "timestamp", "hour_index", "label_sick_now", "label_sick_within_48h"]].copy()]

    grouped = df.groupby("cow_id")

    for col in SENSOR_COLS:
        s = grouped[col]

        # short-term rolling stats (last 6h, 12h) -> captures acute change
        roll6 = s.transform(lambda x: x.rolling(6, min_periods=2).mean())
        roll12 = s.transform(lambda x: x.rolling(12, min_periods=3).mean())
        roll12_std = s.transform(lambda x: x.rolling(12, min_periods=3).std())

        # personal baseline: trailing 7-day mean, shifted 12h so "now" isn't in it
        baseline = s.transform(
            lambda x: x.shift(12).rolling(baseline_hours, min_periods=24).mean()
        )
        baseline = baseline.bfill()

        # trend: slope of last 12h vs previous 12h
        prev12 = s.transform(lambda x: x.shift(12).rolling(12, min_periods=3).mean())

        out.append(pd.DataFrame({
            f"{col}_roll6": roll6,
            f"{col}_roll12": roll12,
            f"{col}_roll12_std": roll12_std,
            f"{col}_baseline": baseline,
            f"{col}_dev_from_baseline": roll12 - baseline,
            f"{col}_trend_12h": roll12 - prev12,
        }))

    feat = pd.concat(out, axis=1)
    feat = feat.fillna(0)
    return feat


FEATURE_COLUMNS = [
    c for base in SENSOR_COLS
    for c in (
        f"{base}_roll6", f"{base}_roll12", f"{base}_roll12_std",
        f"{base}_baseline", f"{base}_dev_from_baseline", f"{base}_trend_12h",
    )
]

# Human-readable names for SHAP / dashboard display
FEATURE_LABELS = {
    "body_temp_c_dev_from_baseline": "Body temp vs. personal baseline",
    "body_temp_c_trend_12h": "Body temp 12h trend",
    "activity_index_dev_from_baseline": "Activity vs. personal baseline",
    "activity_index_trend_12h": "Activity 12h trend",
    "rumination_min_per_hr_dev_from_baseline": "Rumination vs. personal baseline",
    "rumination_min_per_hr_trend_12h": "Rumination 12h trend",
    "heart_rate_bpm_dev_from_baseline": "Heart rate vs. personal baseline",
    "heart_rate_bpm_trend_12h": "Heart rate 12h trend",
}
