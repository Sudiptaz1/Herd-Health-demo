"""
FastAPI serving layer for herd health prediction.

Endpoints:
  GET  /api/herd            -> current risk score for every cow (dashboard feed)
  GET  /api/cow/{cow_id}     -> detailed prediction + SHAP explanation for one cow
  GET  /api/herd/history     -> time series for charts
  GET  /                     -> serves the demo dashboard (static/index.html)
"""

import sys
import os
import joblib
import numpy as np
import pandas as pd
import shap
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "models"))
from features import build_features, FEATURE_COLUMNS, FEATURE_LABELS  # noqa: E402

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "herd_sensor_data.csv")
MODEL_PATH = os.path.join(BASE_DIR, "models", "risk_model.joblib")

app = FastAPI(title="Herd Health Prediction API", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- load everything once at startup ----
_bundle = joblib.load(MODEL_PATH)
MODEL = _bundle["model"]
FEATS = _bundle["feature_columns"]
EXPLAINER = shap.TreeExplainer(MODEL)

RAW = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
FEAT_DF = build_features(RAW)
LATEST_HOUR = FEAT_DF["hour_index"].max()


def _latest_snapshot() -> pd.DataFrame:
    """Most recent feature row per cow."""
    idx = FEAT_DF.groupby("cow_id")["hour_index"].idxmax()
    return FEAT_DF.loc[idx].reset_index(drop=True)


def _risk_level(p: float) -> str:
    if p >= 0.7:
        return "high"
    if p >= 0.35:
        return "medium"
    return "low"


def _predict_row(row: pd.Series):
    X = row[FEATS].values.reshape(1, -1).astype(float)
    proba = float(MODEL.predict_proba(X)[0, 1])
    shap_vals = EXPLAINER.shap_values(X)[0]
    order = np.argsort(-np.abs(shap_vals))[:4]
    top_factors = []
    for i in order:
        fname = FEATS[i]
        contribution = float(shap_vals[i])
        if abs(contribution) < 1e-4:
            continue
        top_factors.append({
            "feature": FEATURE_LABELS.get(fname, fname),
            "impact": round(contribution, 4),
            "direction": "increases risk" if contribution > 0 else "decreases risk",
        })
    return proba, top_factors


@app.get("/api/herd")
def get_herd():
    snap = _latest_snapshot()
    results = []
    for _, row in snap.iterrows():
        proba, factors = _predict_row(row)
        results.append({
            "cow_id": row["cow_id"],
            "risk_pct": round(proba * 100, 1),
            "risk_level": _risk_level(proba),
            "top_factors": factors,
            "last_updated": row["timestamp"].isoformat(),
        })
    results.sort(key=lambda r: -r["risk_pct"])
    return {
        "herd_size": len(results),
        "high_risk_count": sum(1 for r in results if r["risk_level"] == "high"),
        "medium_risk_count": sum(1 for r in results if r["risk_level"] == "medium"),
        "cows": results,
    }


@app.get("/api/cow/{cow_id}")
def get_cow(cow_id: str):
    snap = _latest_snapshot()
    row = snap[snap["cow_id"] == cow_id]
    if row.empty:
        raise HTTPException(404, f"Unknown cow_id: {cow_id}")
    row = row.iloc[0]
    proba, factors = _predict_row(row)

    hist = RAW[RAW["cow_id"] == cow_id].sort_values("hour_index").tail(72)
    history = {
        "timestamps": hist["timestamp"].dt.strftime("%m-%d %H:%M").tolist(),
        "body_temp_c": hist["body_temp_c"].round(2).tolist(),
        "activity_index": hist["activity_index"].round(1).tolist(),
        "rumination_min_per_hr": hist["rumination_min_per_hr"].round(1).tolist(),
        "heart_rate_bpm": hist["heart_rate_bpm"].round(1).tolist(),
    }

    return {
        "cow_id": cow_id,
        "risk_pct": round(proba * 100, 1),
        "risk_level": _risk_level(proba),
        "top_factors": factors,
        "summary": f"{cow_id} has a {proba*100:.0f}% chance of becoming clinically sick within 48 hours.",
        "history": history,
    }


@app.get("/api/health")
def health():
    return {"status": "ok", "herd_size": int(FEAT_DF["cow_id"].nunique()), "hours_of_data": int(LATEST_HOUR)}


static_dir = os.path.join(BASE_DIR, "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def dashboard():
    return FileResponse(os.path.join(static_dir, "index.html"))
